VIA_ENABLE = yes
VIAL_ENABLE = yes
VIAL_INSECURE = yes
LTO_ENABLE = yes  #make the file smaller


DYNAMIC_MACRO_ENABLE = yes
COMBO_ENABLE = yes
TAP_DANCE_ENABLE = yes
KEY_OVERRIDE_ENABLE = yes
QMK_SETTINGS = no
UNICODE_ENABLE = no
BOOTMAGIC_ENABLE = no      # Enable Bootmagic Lite
MOUSEKEY_ENABLE = no       # Mouse keys
EXTRAKEY_ENABLE = yes       # Audio control and System control
CONSOLE_ENABLE = no         # Console for debug
COMMAND_ENABLE = no         # Commands for debug and configuration
CAPS_WORD_ENABLE = no 
LAYER_LOCK_ENABLE = no 
REPEAT_KEY_ENABLE = no