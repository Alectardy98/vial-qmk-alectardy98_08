# EC Pro X — experimental TinyUF2 variant

Independent STM32F411 variant of the Cipulot-derived EC Pro X acquisition driver
and shared Alectardy98 EC42 v2.9 engine. The original `ec_prox` target is unchanged.
This variant has compiled and passed offline tests; it is **not hardware-tested**.

```sh
make alectardy98_ec/ec_prox_uf2:vial
make alectardy98_ec/ec_prox_uf2:vial_alec
```

These normal builds generate application-only UF2 files in the repository root
and `.build/`. They require the separately built EC Prox TinyUF2 bootloader;
**do not install these images using the original Prox clean-install procedure**.

- Bootloader: `0x08000000–0x08007FFF` (sectors 0–1).
- EEPROM: `0x08008000–0x0800BFFF` (sector 2, 8 KiB journal/4 KiB logical).
- Reserved: `0x0800C000–0x0800FFFF` (sector 3).
- Application: `0x08010000–0x0803FFFF` (sectors 4–5).
- UF2 family: `0x57755A57`; normal UF2 updates cannot target EEPROM or loader.

Initial installation intentionally requires fresh Vial setup/calibration. There
is no migration from the original sector-1 storage. Subsequent UF2 updates retain
sector-2 storage and the pinned Vial EEPROM build ID. Application USB identity,
Vial UID, physical layout and EC42 record schema match the original Prox, so the
existing universal GUI profile works without changes.

The source selects F411 following the user's CubeProgrammer identification
`STM32F411xC/E / 0x431`, instead of the original source's F401 setting. It retains
84 MHz/8 MHz HSE configuration, original GPIO startup defaults, mux timing,
ADC acquisition and matrix scanner. Only 256 KiB flash and 64 KiB RAM are used.

See `development/alectardy98_ec/tinyuf2/REPORT.md` for artifacts, hashes, offline
validation limitations, first-install requirements and recovery. Establish an
independent ROM DFU or SWD recovery route before installing a new bootloader.
No hardware was flashed during development.

Original acquisition/configuration copyright and GPL notices remain intact.
TinyUF2 and its MIT-licensed components are maintained in the separate TinyUF2
checkout; its adapted sources and exact patch are included with the build.
