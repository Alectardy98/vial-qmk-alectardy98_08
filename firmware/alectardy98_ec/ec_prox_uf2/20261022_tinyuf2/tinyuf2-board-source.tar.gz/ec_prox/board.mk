# F411 confirmed by CubeProgrammer device ID 0x431. HSE matches original Prox.
CFLAGS += -DSTM32F411xE -DHSE_VALUE=8000000U
SRC_S += $(ST_CMSIS)/Source/Templates/gcc/startup_stm32f411xe.s
JLINK_DEVICE = STM32F411CE
ifndef BUILD_APPLICATION
LD_FILES = $(BOARD_DIR)/boot.ld
endif
